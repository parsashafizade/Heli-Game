#ifndef C3684005_CF6C_41F8_8E71_6B0F5EC590EF
#define C3684005_CF6C_41F8_8E71_6B0F5EC590EF
#include <iostream>
#include <string>
#include "MyHeli.hpp"
#include "Enemy.hpp"
#include "Laser.hpp"

class GamePlay 
{
private:
        
    int width;
    int height;

    std::string GameLevel;

    bool exitGame;
    bool gameOver;

public:
    void SETXY(int x, int y);
    void Preparation(std::string gamelevel);
    void layout();
    void input();
    void Logic1();
    void Logic2();
    void hideCursor();
    void inScore();
    void game_Over();
    void game_Saved();
    void Moving();
    void Death();
    void play();
    void reposition();
    void playLoadGame();
    void chosseLEVEL();
    void EasyGame();
    void MediumGame();
    void HardGame();
    int  games();
    int  LoadstartUp();
};
#endif /* C3684005_CF6C_41F8_8E71_6B0F5EC590EF */
