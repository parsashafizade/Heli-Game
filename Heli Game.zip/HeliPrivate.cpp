#include "./HeliHeader.hpp"
#include <windows.h>
#include <stdlib.h>
#include <time.h>
#include <conio.h>
#include <fstream>
#include <chrono>
#include <thread>

using namespace std;

void heli::SETXY(int x, int y)
{ // to print in any place you want
    COORD coord;
    coord.X = x;
    coord.Y = y;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}

void heli::hideCursor()
{ // to hide cursor
    CONSOLE_CURSOR_INFO cursor;
    cursor.dwSize = 100;
    cursor.bVisible = false;
    SetConsoleCursorInfo(GetStdHandle(STD_OUTPUT_HANDLE), &cursor);
}

void heli::Preparation(string gamelevel)
{ // all values once the game starts
    srand(time(NULL));
    GameLevel = gamelevel;
    exitGame = false;
    Move = false;
    gameOver = false;
    dead = false;
    Collision = false;
    life = 3;
    height = 20;
    width = 20;
    myHeliX = 8;
    myHeliY = 16;
    myLaserX = 8;
    myLaserY = 4;
    Location = 1;
    NumberOfEnemys = 2;
    score = 0;

    for (int i = 0; i < NumberOfEnemys; i++)
    {
        EPX = rand() % 3;
        if (EPX == 0)
            enemyX[i] = 2;
        else if (EPX == 1)
            enemyX[i] = 8;
        else if (EPX == 2)
            enemyX[i] = 14;
    }
    enemyY[0] = -8;
    enemyY[1] = -18;
    enemyY[2] = -28;
    enemyY[3] = -38;
}

int heli::LoadstartUp()
{ // all values once the game starts
    // Read player data from the text file
    ifstream inFile("player.txt");
    if (inFile.is_open())
    {
        inFile >> GameLevel;
        inFile >> score;
        inFile >> life;
        inFile >> Location;
        inFile >> myHeliX;
        inFile >> myHeliY;
        inFile >> myLaserX;
        inFile >> myLaserY;
        inFile.close();
    }
    else
    {
        cerr << "Unable to open file for reading." << endl;
    }

    srand(time(NULL));
    exitGame = false;
    Move = false;
    gameOver = false;
    dead = false;
    Collision = false;
    height = 20;
    width = 20;
    NumberOfEnemys = 2;
    for (int i = 0; i < NumberOfEnemys; i++)
    {
        EPX = rand() % 3;
        if (EPX == 0)
            enemyX[i] = 2;
        else if (EPX == 1)
            enemyX[i] = 8;
        else if (EPX == 2)
            enemyX[i] = 14;
    }
    enemyY[0] = -8;
    enemyY[1] = -18;
    enemyY[2] = -28;
    enemyY[3] = -38;
    if (GameLevel == "EASY")
    {
        return 1;
    }
    else if (GameLevel == "MEIUM")
    {
        return 2;
    }
    else
    {
        return 3;
    }
}

void heli::reposition()
{

    myHeliX = 8;
    myHeliY = 16;
    myLaserX = 8;
    myLaserY = 4;
    Location = 1;

    for (int i = 0; i < NumberOfEnemys; i++)
    {
        EPX = rand() % 3;
        if (EPX == 0)
            enemyX[i] = 2;
        else if (EPX == 1)
            enemyX[i] = 8;
        else if (EPX == 2)
            enemyX[i] = 14;
    }
    enemyY[0] = -8;
    enemyY[1] = -18;
    enemyY[2] = -28;
    enemyY[3] = -38;
}

void heli::layout()
{ // to print the game layout
    for (int i = 0; i < height; i++)
    {
        SETXY(0, i);
        cout << "|                  |";
        if (i % 2 == 0 && Move)
        {
            SETXY(6, i);
            cout << "        ";
        }
        else if (i % 2 != 0 && !Collision)
        {
            SETXY(6, i);
            cout << "        ";
        }
    }
    SETXY(5, 21);
    cout << "Life: " << life;
    SETXY(5, 22);
    cout << "Score: " << score;
}

void heli::drawMyHeli()
{ // to print your Heli
    if (!dead)
    {
        for (int i = 0; i < 4; i++)
        {
            SETXY(myHeliX, myHeliY + i);
            cout << myHeli[i];
        }
    }
    else
    {
        for (int i = 0; i < 4; i++)
        {
            SETXY(myHeliX, myHeliY + i);
            cout << "    ";
        }
    }
}
void heli::drawMyLasere()
{ // to print your Heli Lasere
    if (!dead)
    {
        Sleep(2);
        for (int i = 0; i < 11; i++)
        {
            SETXY(myLaserX, myLaserY + i);
            cout << Laser1[i];
        }
        Sleep(2);
        for (int i = 0; i < 11; i++)
        {
            SETXY(myLaserX, myLaserY + i + 1);
            cout << Laser1[i];
        }
    }
    else
    {
        for (int i = 0; i < 11; i++)
        {
            SETXY(myLaserX, myLaserY + i);
            cout << "    ";
        }
    }
}

void heli::inScore()
{
    score += 1;
}

void heli::drawEnemyHeli()
{ // to print enemy Heli
    for (int i = 0; i < NumberOfEnemys; i++)
    {
        if (enemyY[i] + 3 > 0)
        {
            SETXY(enemyX[i], enemyY[i] + 3);
            cout << " # ";
        }
        if (enemyY[i] + 2 > 0)
        {
            SETXY(enemyX[i], enemyY[i] + 2);
            cout << "# #";
        }
        if (enemyY[i] + 3 > height)
        {
            SETXY(enemyX[i], enemyY[i] + 3);
            cout << "   ";
        }
        if (enemyY[i] + 2 > height)
        {
            SETXY(enemyX[i], enemyY[i] + 2);
            cout << "   ";
        }
        if (enemyY[i] + 1 > height)
        {
            SETXY(enemyX[i], enemyY[i] + 1);
            cout << "   ";
        }
        if (enemyY[i] > height)
        {
            SETXY(enemyX[i], enemyY[i]);
            cout << "   ";
        }
    }
}

void heli::input()
{ // to control your Heli using keyboard input
    if (_kbhit())
    {
        switch (_getch())
        {
        case 72:
            if (myHeliY > 0 && !dead)
            {
                myHeliY -= Location;
                myLaserY -= Location;
            }
            break;
        case 75:
            if (myHeliX > 2 && !dead)
            {
                myHeliX -= 6;
                myLaserX -= 6;
            }
            break;
        case 77:
            if (myHeliX < 14 && !dead)
            {
                myHeliX += 6;
                myLaserX += 6;
            }
            break;
        case 80:
            if (myHeliY < 16 && !dead)
            {
                myHeliY += Location;
                myLaserY += Location;
            }
            break;
        case 115:
            // Write player data to a text file
            ofstream outFile("player.txt");
            if (outFile.is_open())
            {
                outFile << GameLevel << endl;
                outFile << score << endl;
                outFile << life << endl;
                outFile << Location << endl;
                outFile << myHeliX << endl;
                outFile << myHeliY << endl;
                outFile << myLaserX << endl;
                outFile << myLaserY << endl;
                outFile.close();
                cout << endl
                     << "Player data has been saved to file." << endl;
            }
            else
            {
                cerr << "Unable to open file for writing." << endl;
                return;
            }
            game_Saved();
            break;
        }
    }
}

void heli::CollisionHeli()
{ // to print bomb explosion effect
    if (Collision)
    {
        for (int i = 0; i < 4; i++)
        {
            SETXY(myHeliX - 1, myHeliY - 1 + i);
            cout << Collision1[i] << endl;
        }
        Collision = false;
    }
    else
    {
        for (int i = 0; i < 4; i++)
        {
            SETXY(myHeliX - 1, myHeliY - 1 + i);
            cout << Collision2[i] << endl;
        }
        Collision = true;
    }
    Sleep(100);
}

void heli::Death()
{ // logic when your character crash
    dead = true;
    life -= 1;
    int count = 0;
    while (count != 10)
    {
        input();
        CollisionHeli();
        SETXY(2, 22);
        cout << "You got " << score << " Score!";
        count++;
    }
    SETXY(2, 22);
    cout << "                    ";
    reposition();
    dead = false;
}

void heli::createenemy()
{
    for (int i = 0; i < NumberOfEnemys; i++)
    { // setting new enemy positions
        if (enemyY[i] > 21)
        {
            EPX = rand() % 3;
            if (EPX == 0)
                enemyX[i] = 2;
            else if (EPX == 1)
                enemyX[i] = 8;
            else if (EPX == 2)
                enemyX[i] = 14;
            enemyY[i] = -8;
            // score += 1;
        }
    }
}

void heli::Logic1()
{ // all mechanics, rules and logics
    srand(time(NULL));
    for (int i = 0; i < NumberOfEnemys; i++)
    {
        enemyY[i] += 1;
    }
    createenemy();

    for (int i = 0; i < NumberOfEnemys; i++)
    { // checking collisions between 'myHeli' and 'enemies'
        if (((myHeliY <= enemyY[i] + 3 && myHeliY >= enemyY[i])) && myHeliX == enemyX[i] || enemyY[i] == 16)
        {
            // dead = true;
            Death();
        }
        else if (myHeliX == enemyX[i])
        {
            enemyHP = rand() % 2;
            if (enemyHP == 1)
            {
                if (enemyX[i] == 2)
                {
                    enemyX[i] = 8;
                    enemyY[i] = enemyY[i] - 5;
                    SETXY(enemyX[i], enemyY[i] + 3);
                    cout << " # ";
                    SETXY(enemyX[i], enemyY[i] + 2);
                    cout << "# #";
                    SETXY(enemyX[i], enemyY[i] + 3);
                    cout << "   ";
                    SETXY(enemyX[i], enemyY[i] + 2);
                    cout << "   ";
                    SETXY(enemyX[i], enemyY[i] + 1);
                    cout << "   ";
                    SETXY(enemyX[i], enemyY[i]);
                    cout << "   ";
                    Logic2();
                }
                else if (enemyX[i] == 14)
                {
                    enemyX[i] = 8;
                    enemyY[i] = enemyY[i] - 5;
                    SETXY(enemyX[i], enemyY[i] + 3);
                    cout << " # ";
                    SETXY(enemyX[i], enemyY[i] + 2);
                    cout << "# #";
                    SETXY(enemyX[i], enemyY[i] + 3);
                    cout << "   ";
                    SETXY(enemyX[i], enemyY[i] + 2);
                    cout << "   ";
                    SETXY(enemyX[i], enemyY[i] + 1);
                    cout << "   ";
                    SETXY(enemyX[i], enemyY[i]);
                    cout << "   ";
                    Logic2();
                }
            }
            else
            {
                enemyY[i] = 21;
            }
            createenemy();
            inScore();
        }
    }
}

void heli::Logic2()
{
    for (int i = 0; i < NumberOfEnemys; i++)
    {
        if (myHeliX == enemyX[i])
        {
            enemyY[i] = 21;
        }
        createenemy();
        inScore();
    }
}

void heli::Moving()
{ // to print transition
    for (int i = 19; i >= 0; i--)
    {
        SETXY(1, i);
        cout << "~~~~~~~~~~~~~~~~~~~";
        Sleep(15);
    }
    for (int i = 1; i < 20; i++)
    {
        SETXY(1, i);
        cout << "                  ";
        Sleep(15);
    }
}

int heli::games()
{
    SETXY(0, 0);
    cout << "____________________";
    SETXY(0, 1);
    cout << "|                  |";
    SETXY(0, 2);
    cout << "|                  |";
    SETXY(0, 3);
    cout << "|    HELI GAME     |";
    SETXY(0, 4);
    cout << "|                  |";
    SETXY(0, 4);
    cout << "|                  |";
    SETXY(0, 5);
    cout << "|                  |";
    SETXY(0, 6);
    cout << "|                  |";
    SETXY(0, 7);
    cout << "|    TO START      |";
    SETXY(0, 8);
    cout << "|  PRESS 'SPACE'   |";
    SETXY(0, 9);
    cout << "|    TO LOAD       |";
    SETXY(0, 10);
    cout << "|    PRESS 'L'     |";
    SETXY(0, 11);
    cout << "|                  |";
    SETXY(0, 12);
    cout << "|                  |";
    SETXY(0, 13);
    cout << "|                  |";
    SETXY(0, 14);
    cout << "|                  |";
    SETXY(0, 15);
    cout << "|                  |";
    SETXY(0, 16);
    cout << "|                  |";
    SETXY(0, 17);
    cout << "|                  |";
    SETXY(0, 18);
    cout << "____________________";

    switch (_getch())
    {
    case 32:
        return 1;
        break;
    case 108:
        return 2;
        break;
    }
    return 1;
}

void heli::game_Over()
{ // when player's life == 0

    if (life == 0)
    {
        gameOver = true;
        do
        {
            SETXY(0, 0);
            cout << "____________________";
            SETXY(0, 1);
            cout << "|                  |";
            SETXY(0, 2);
            cout << "|                  |";
            SETXY(0, 3);
            cout << "|                  |";
            SETXY(0, 4);
            cout << "|                  |";
            SETXY(0, 5); 
            cout << "|                  |";
            SETXY(0, 6);
            cout << "|    GAME OVER!!   |";
            SETXY(0, 7);
            cout << "|                  |";
            SETXY(0, 8);
            cout << "|     HIGHSCORE    |";
            SETXY(0, 9);
            cout << "|                  |";
            SETXY(0, 10);
            cout << "       " << score << "      ";
            SETXY(0, 11);
            cout << "|                  |";
            SETXY(0, 12);
            cout << "|    PRESS   'X'   |";
            SETXY(0, 13); 
            cout << "|        EXIT      |";
            SETXY(0, 14);
            cout << "|                  |";
            SETXY(0, 15);
            cout << "|                  |";
            SETXY(0, 16);
            cout << "|                  |";
            SETXY(0, 17);
            cout << "|                  |";
            SETXY(0, 18);
            cout << "|                  |";
            SETXY(0, 19);
            cout << "____________________";
        } while (getch() != 'x');
        exit(1);
    }
}

void heli::chosseLEVEL()
{
    SETXY(0, 0);
    cout << "____________________";
    SETXY(0, 1);
    cout << "|                  |";
    SETXY(0, 2);
    cout << "|                  |";
    SETXY(0, 3);
    cout << "|    HELI GAME     |";
    SETXY(0, 4);
    cout << "|                  |";
    SETXY(0, 4);
    cout << "|                  |";
    SETXY(0, 5);
    cout << "|    EASY LEVEL    |";
    SETXY(0, 6);
    cout << "|     PRESS 'E'    |";
    SETXY(0, 7);
    cout << "|   MEDIUM LEVEL   |";
    SETXY(0, 8);
    cout << "|     PRESS 'M'    |";
    SETXY(0, 9);
    cout << "|    HARD LEVEL    |";
    SETXY(0, 10);
    cout << "|     PRESS 'H'    |";
    SETXY(0, 11);
    cout << "|                  |";
    SETXY(0, 12); 
    cout << "|                  |";
    SETXY(0, 13);
    cout << "|                  |";
    SETXY(0, 14);
    cout << "|                  |";
    SETXY(0, 15);
    cout << "|                  |";
    SETXY(0, 16);
    cout << "|                  |";
    SETXY(0, 17);
    cout << "|                  |";
    SETXY(0, 18);
    cout << "|                  |";
    SETXY(0, 19); 
    cout << "____________________";

    switch (_getch())
    {
    case 101:
        EasyGame();
        break;
    case 109:
        MediumGame();
        break;
    case 104:
        HardGame();
        break;
    }
}

void heli::game_Saved()
{
    do
    {
    SETXY(0, 0);
    cout << "____________________";
    SETXY(0, 1);
    cout << "|                  |";
    SETXY(0, 2);
    cout << "|                  |";
    SETXY(0, 3);
    cout << "|    HELI GAME     |";
    SETXY(0, 4);
    cout << "|                  |";
    SETXY(0, 4);
    cout << "|                  |";
    SETXY(0, 5);
    cout << "|                  |";
    SETXY(0, 6);
    cout << "|   GAME Saved!!   |";
    SETXY(0, 7);
    cout << "|                  |";
    SETXY(0, 8);
    cout << "|                  |";
    SETXY(0, 9);
    cout << "|                  |";
    SETXY(0, 10);
    cout << "|                  |";
    SETXY(0, 11);
    cout << "|                  |";
    SETXY(0, 12);
    cout << "|                  |";
    SETXY(0, 13); 
    cout << "|                  |";
    SETXY(0, 14);
    cout << "|   PRESS   'X'    |";
    SETXY(0, 15);
    cout << "|    TO EXIT       |";
    SETXY(0, 16);
    cout << "|                  |";
    SETXY(0, 17);
    cout << "|                  |";
    SETXY(0, 18);
    cout << "|                  |";
    SETXY(0, 19);
    cout << "____________________";
    } while (getch() != 'x');
    exit(1);
}

void heli::play()
{
    int chosse;
    hideCursor();
    Moving();
    chosse = games();
    switch (chosse)
    {
    case 1:
        chosseLEVEL();
        break;
    case 2:
        playLoadGame();
    default:
        break;
    }
}

void heli::playLoadGame()
{
    int level;
    int levelspeed;
    hideCursor();
    level = LoadstartUp();

    if (level == 1)
    {
        levelspeed = 40;
    }

    else if (level == 2)
    {
        levelspeed = 15;
    }

    else
    {
        levelspeed = 1;
    }

    Moving();
    while (!dead)
    {
        layout();
        input();
        Logic1();
        Logic2();
        drawMyHeli();
        drawMyLasere();
        drawEnemyHeli();
        game_Over();
        Sleep(levelspeed);
    }
    system("cls");
    cout << "\n\n\n\n\tThank You for playing!!";
}

void heli::EasyGame()
{

    hideCursor();
    Preparation("EASY");
    Moving();
    while (!dead)
    {
        layout();
        input();
        Logic1();
        Logic2();
        drawMyHeli();
        drawMyLasere();
        drawEnemyHeli();
        game_Over();
        Sleep(40);
    }
    system("cls");
    cout << "\n\n\n\n\tThank You for playing!!";
}
void heli::MediumGame()
{
    hideCursor();
    Preparation("MEDIUM");
    Moving();
    while (!dead)
    {
        layout();
        input();
        Logic1();
        Logic2();
        drawMyHeli();
        drawMyLasere();
        drawEnemyHeli();
        game_Over();
        Sleep(15);
    }
    system("cls");
    cout << "\n\n\n\n\tThank You for playing!!";
}
void heli::HardGame()
{
    hideCursor();
    Preparation("HARD");
    Moving();
    while (!dead)
    {
        layout();
        input();
        Logic1();
        Logic2();
        drawMyHeli();
        drawMyLasere();
        drawEnemyHeli();
        game_Over();
        Sleep(1);
    }
    system("cls");
    cout << "\n\n\n\n\tThank You for playing!!";
}