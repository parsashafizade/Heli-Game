#include "GamePlay.hpp"
#include "MyHeli.hpp"
#include "Enemy.hpp"
#include "Laser.hpp"
#include <iostream>
#include <windows.h>
#include <stdlib.h>
#include <time.h>
#include <conio.h>
#include <fstream>
#include <chrono>
#include <thread>

using namespace std;

MyHeli Heli;
EnemyHeli Enemy;
MyLaser Laser;

void GamePlay::SETXY(int x, int y)
{
// to print in any place you want
    COORD coord;
    coord.X = x;
    coord.Y = y;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}

void GamePlay::Preparation(std::string gamelevel )
{
    // all values once the game starts
    srand(time(NULL));
    GameLevel = gamelevel;
    exitGame = false;
    Heli.Move = false;
    gameOver = false;
    Heli.dead = false;
    Heli.Collision = false;
    Heli.life = 3;
    height = 20;
    width = 20;
    Heli.myHeliX = 8;
    Heli.myHeliY = 16;
    Laser.myLaserX = 8;
    Laser.myLaserY = 4;
    Heli.Location = 1;
    Enemy.NumberOfEnemys = 2;
    Heli.score = 0;

    for (int i = 0; i < Enemy.NumberOfEnemys; i++)
    {
        Enemy.EPX = rand() % 3;
        if (Enemy.EPX == 0)
            Enemy.enemyX[i] = 2;
        else if (Enemy.EPX == 1)
            Enemy.enemyX[i] = 8;
        else if (Enemy.EPX == 2)
            Enemy.enemyX[i] = 14;
    }
    Enemy.enemyY[0] = -8;
    Enemy.enemyY[1] = -18;
    Enemy.enemyY[2] = -28;
    Enemy.enemyY[3] = -38;
}

void GamePlay::layout()
{// to print the game layout
    for (int i = 0; i < height; i++)
    {
        SETXY(0, i);
        cout << "|                  |";
        if (i % 2 == 0 && Heli.Move)
        {
            SETXY(6, i);
            cout << "        ";
        }
        else if (i % 2 != 0 && !Heli.Collision)
        {
            SETXY(6, i);
            cout << "        ";
        }
    }
    SETXY(5, 21);
    cout << "Life: " << Heli.life;
    SETXY(5, 22);
    cout << "Score: " << Heli.score;
}

void GamePlay::input()
{
    // to control your Heli using keyboard input
    if (_kbhit())
    {
        switch (_getch())
        {
        case 72:
            if (Heli.myHeliY > 0 && !Heli.dead)
            {
                Heli.myHeliY -= Heli.Location;
                Laser.myLaserY -= Heli.Location;
            }
            break;
        case 75:
            if (Heli.myHeliX > 2 && !Heli.dead)
            {
                Heli.myHeliX -= 6;
                Laser.myLaserX -= 6;
            }
            break;
        case 77:
            if (Heli.myHeliX < 14 && !Heli.dead)
            {
                Heli.myHeliX += 6;
                Laser.myLaserX += 6;
            }
            break;
        case 80:
            if (Heli.myHeliY < 16 && !Heli.dead)
            {
                Heli.myHeliY += Heli.Location;
                Laser.myLaserY += Heli.Location;
            }
            break;
        case 115:
            // Write player data to a text file
            ofstream outFile("player.txt");
            if (outFile.is_open())
            {
                outFile << GameLevel << endl;
                outFile << Heli.score << endl;
                outFile << Heli.life << endl;
                outFile << Heli.Location << endl;
                outFile << Heli.myHeliX << endl;
                outFile << Heli.myHeliY << endl;
                outFile << Laser.myLaserX << endl;
                outFile << Laser.myLaserY << endl;
                outFile.close();
                cout << endl
                     << "Player data has been saved to file." << endl;
            }
            else
            {
                cerr << "Unable to open file for writing." << endl;
                return;
            }
            game_Saved();
            break;
        }
    }
}

void GamePlay::Logic1()
{// all mechanics, rules and logics
    srand(time(NULL));
    for (int i = 0; i < Enemy.NumberOfEnemys; i++)
    {
        Enemy.enemyY[i] += 1;
    }
    Enemy.createenemy();

    for (int i = 0; i < Enemy.NumberOfEnemys; i++)
    { // checking collisions between 'myHeli' and 'enemies'
        if (((Heli.myHeliY <= Enemy.enemyY[i] + 3 && Heli.myHeliY >= Enemy.enemyY[i])) && Heli.myHeliX == Enemy.enemyX[i] || Enemy.enemyY[i] == 16)
        {
            // dead = true;
            Death();
        }
        else if (Heli.myHeliX == Enemy.enemyX[i])
        {
            Enemy.enemyHP = rand() % 2;
            if (Enemy.enemyHP == 1)
            {
                if (Enemy.enemyX[i] == 2)
                {
                    Enemy.enemyX[i] = 8;
                    Enemy.enemyY[i] = Enemy.enemyY[i] - 5;
                    SETXY(Enemy.enemyX[i], Enemy.enemyY[i] + 3);
                    cout << " # ";
                    SETXY(Enemy.enemyX[i], Enemy.enemyY[i] + 2);
                    cout << "# #";
                    SETXY(Enemy.enemyX[i], Enemy.enemyY[i] + 3);
                    cout << "   ";
                    SETXY(Enemy.enemyX[i], Enemy.enemyY[i] + 2);
                    cout << "   ";
                    SETXY(Enemy.enemyX[i], Enemy.enemyY[i] + 1);
                    cout << "   ";
                    SETXY(Enemy.enemyX[i], Enemy.enemyY[i]);
                    cout << "   ";
                    Logic2();
                }
                else if (Enemy.enemyX[i] == 14)
                {
                    Enemy.enemyX[i] = 8;
                    Enemy.enemyY[i] = Enemy.enemyY[i] - 5;
                    SETXY(Enemy.enemyX[i], Enemy.enemyY[i] + 3);
                    cout << " # ";
                    SETXY(Enemy.enemyX[i], Enemy.enemyY[i] + 2);
                    cout << "# #";
                    SETXY(Enemy.enemyX[i], Enemy.enemyY[i] + 3);
                    cout << "   ";
                    SETXY(Enemy.enemyX[i], Enemy.enemyY[i] + 2);
                    cout << "   ";
                    SETXY(Enemy.enemyX[i], Enemy.enemyY[i] + 1);
                    cout << "   ";
                    SETXY(Enemy.enemyX[i], Enemy.enemyY[i]);
                    cout << "   ";
                    Logic2();
                }
            }
            else
            {
                Enemy.enemyY[i] = 21;
            }
            Enemy.createenemy();
            inScore();
        }
    }
}

void GamePlay::Logic2()
{
    for (int i = 0; i < Enemy.NumberOfEnemys; i++)
    {
        if (Heli.myHeliX == Enemy.enemyX[i])
        {
            Enemy.enemyY[i] = 21;
        }
        Enemy.createenemy();
        inScore();
    }
}

void GamePlay::hideCursor()
{
    // to hide cursor
    CONSOLE_CURSOR_INFO cursor;
    cursor.dwSize = 100;
    cursor.bVisible = false;
    SetConsoleCursorInfo(GetStdHandle(STD_OUTPUT_HANDLE), &cursor);
}

void GamePlay::inScore()
{
    Heli.score += 1;
}

void GamePlay::game_Over()
{
    // when player's life == 0

    if (Heli.life == 0)
    {
        gameOver = true;
        do
        {
            SETXY(0, 0);
            cout << "____________________";
            SETXY(0, 1);
            cout << "|                  |";
            SETXY(0, 2);
            cout << "|                  |";
            SETXY(0, 3);
            cout << "|                  |";
            SETXY(0, 4);
            cout << "|                  |";
            SETXY(0, 5); 
            cout << "|                  |";
            SETXY(0, 6);
            cout << "|    GAME OVER!!   |";
            SETXY(0, 7);
            cout << "|                  |";
            SETXY(0, 8);
            cout << "|     HIGHSCORE    |";
            SETXY(0, 9);
            cout << "|                  |";
            SETXY(0, 10);
            cout << "       " << Heli.score << "      ";
            SETXY(0, 11);
            cout << "|                  |";
            SETXY(0, 12);
            cout << "|    PRESS   'X'   |";
            SETXY(0, 13); 
            cout << "|        EXIT      |";
            SETXY(0, 14);
            cout << "|                  |";
            SETXY(0, 15);
            cout << "|                  |";
            SETXY(0, 16);
            cout << "|                  |";
            SETXY(0, 17);
            cout << "|                  |";
            SETXY(0, 18);
            cout << "|                  |";
            SETXY(0, 19);
            cout << "____________________";
        } while (getch() != 'x');
        exit(1);
    }
}

void GamePlay::game_Saved()
{
     do
    {
    SETXY(0, 0);
    cout << "____________________";
    SETXY(0, 1);
    cout << "|                  |";
    SETXY(0, 2);
    cout << "|                  |";
    SETXY(0, 3);
    cout << "|    HELI GAME     |";
    SETXY(0, 4);
    cout << "|                  |";
    SETXY(0, 4);
    cout << "|                  |";
    SETXY(0, 5);
    cout << "|                  |";
    SETXY(0, 6);
    cout << "|   GAME Saved!!   |";
    SETXY(0, 7);
    cout << "|                  |";
    SETXY(0, 8);
    cout << "|                  |";
    SETXY(0, 9);
    cout << "|                  |";
    SETXY(0, 10);
    cout << "|                  |";
    SETXY(0, 11);
    cout << "|                  |";
    SETXY(0, 12);
    cout << "|                  |";
    SETXY(0, 13); 
    cout << "|                  |";
    SETXY(0, 14);
    cout << "|   PRESS   'X'    |";
    SETXY(0, 15);
    cout << "|    TO EXIT       |";
    SETXY(0, 16);
    cout << "|                  |";
    SETXY(0, 17);
    cout << "|                  |";
    SETXY(0, 18);
    cout << "|                  |";
    SETXY(0, 19);
    cout << "____________________";
    } while (getch() != 'x');
    exit(1);
}

void GamePlay::Death()
{ // logic when your character crash
    Heli.dead = true;
    Heli.life -= 1;
    int count = 0;
    while (count != 10)
    {
        input();
        Heli.CollisionHeli();
        SETXY(2, 22);
        cout << "You got " << Heli.score << " Score!";
        count++;
    }
    SETXY(2, 22);
    cout << "                    ";
    reposition();
    Heli.dead = false;
}
void GamePlay::reposition(){
    Heli.myHeliX = 8;
    Heli.myHeliY = 16;
    Laser.myLaserX = 8;
    Laser.myLaserY = 4;
    Heli.Location = 1;

    for (int i = 0; i < Enemy.NumberOfEnemys; i++)
    {
        Enemy.EPX = rand() % 3;
        if (Enemy.EPX == 0)
            Enemy.enemyX[i] = 2;
        else if (Enemy.EPX == 1)
            Enemy.enemyX[i] = 8;
        else if (Enemy.EPX == 2)
            Enemy.enemyX[i] = 14;
    }
    Enemy.enemyY[0] = -8;
    Enemy.enemyY[1] = -18;
    Enemy.enemyY[2] = -28;
    Enemy.enemyY[3] = -38;
}

void GamePlay::play()
{
    int chosse;
    hideCursor();
    Moving();
    chosse = games();
    switch (chosse)
    {
    case 1:
        chosseLEVEL();
        break;
    case 2:
        playLoadGame();
    default:
        break;
    }
}

void GamePlay::playLoadGame()
{
    int level;
    int levelspeed;
    hideCursor();
    level = LoadstartUp();

    if (level == 1)
    {
        levelspeed = 40;
    }

    else if (level == 2)
    {
        levelspeed = 15;
    }

    else
    {
        levelspeed = 1;
    }

    Moving();
    while (!Heli.dead)
    {
        layout();
        input();
        Logic1();
        Logic2();
        Heli.drawMyHeli();
        Laser.drawMyLasere();
        Enemy.drawEnemyHeli();
        game_Over();
        Sleep(levelspeed);
    }
    system("cls");
    cout << "\n\n\n\n\tThank You for playing!!";
}

void GamePlay::Moving()
{
// to print transition
    for (int i = 19; i >= 0; i--)
    {
        SETXY(1, i);
        cout << "~~~~~~~~~~~~~~~~~~~";
        Sleep(15);
    }
    for (int i = 1; i < 20; i++)
    {
        SETXY(1, i);
        cout << "                  ";
        Sleep(15);
    }
}

void GamePlay::chosseLEVEL()
{
    SETXY(0, 0);
    cout << "____________________";
    SETXY(0, 1);
    cout << "|                  |";
    SETXY(0, 2);
    cout << "|                  |";
    SETXY(0, 3);
    cout << "|    HELI GAME     |";
    SETXY(0, 4);
    cout << "|                  |";
    SETXY(0, 4);
    cout << "|                  |";
    SETXY(0, 5);
    cout << "|    EASY LEVEL    |";
    SETXY(0, 6);
    cout << "|     PRESS 'E'    |";
    SETXY(0, 7);
    cout << "|   MEDIUM LEVEL   |";
    SETXY(0, 8);
    cout << "|     PRESS 'M'    |";
    SETXY(0, 9);
    cout << "|    HARD LEVEL    |";
    SETXY(0, 10);
    cout << "|     PRESS 'H'    |";
    SETXY(0, 11);
    cout << "|                  |";
    SETXY(0, 12);
    cout << "|                  |";
    SETXY(0, 13);
    cout << "|                  |";
    SETXY(0, 14);
    cout << "|                  |";
    SETXY(0, 15);
    cout << "|                  |";
    SETXY(0, 16);
    cout << "|                  |";
    SETXY(0, 17);
    cout << "|                  |";
    SETXY(0, 18);
    cout << "|                  |";
    SETXY(0, 19);
    cout << "____________________";

    switch (_getch())
    {
    case 101:
        EasyGame();
        break;
    case 109:
        MediumGame();
        break;
    case 104:
        HardGame();
        break;
    }
}

void GamePlay::EasyGame()
{
    hideCursor();
    Preparation("EASY");
    Moving();
    while (!Heli.dead)
    {
        layout();
        input();
        Logic1();
        Logic2();
        Heli.drawMyHeli();
        Laser.drawMyLasere();
        Enemy.drawEnemyHeli();
        game_Over();
        Sleep(40);
    }
    system("cls");
    cout << "\n\n\n\n\tThank You for playing!!";
}

void GamePlay::MediumGame()
{
    hideCursor();
    Preparation("MEDIUM");
    Moving();
    while (!Heli.dead)
    {
        layout();
        input();
        Logic1();
        Logic2();
        Heli.drawMyHeli();
        Laser.drawMyLasere();
        Enemy.drawEnemyHeli();
        game_Over();
        Sleep(15);
    }
    system("cls");
    cout << "\n\n\n\n\tThank You for playing!!";
}

void GamePlay::HardGame()
{
    hideCursor();
    Preparation("HARD");
    Moving();
    while (!Heli.dead)
    {
        layout();
        input();
        Logic1();
        Logic2();
        Heli.drawMyHeli();
        Laser.drawMyLasere();
        Enemy.drawEnemyHeli();
        game_Over();
        Sleep(1);
    }
    system("cls");
    cout << "\n\n\n\n\tThank You for playing!!";
}

int GamePlay::games()
{
    SETXY(0, 0);
    cout << "____________________";
    SETXY(0, 1);
    cout << "|                  |";
    SETXY(0, 2);
    cout << "|                  |";
    SETXY(0, 3);
    cout << "|    HELI GAME     |";
    SETXY(0, 4);
    cout << "|                  |";
    SETXY(0, 4);
    cout << "|                  |";
    SETXY(0, 5);
    cout << "|                  |";
    SETXY(0, 6);
    cout << "|                  |";
    SETXY(0, 7);
    cout << "|    TO START      |";
    SETXY(0, 8);
    cout << "|  PRESS 'SPACE'   |";
    SETXY(0, 9);
    cout << "|    TO LOAD       |";
    SETXY(0, 10);
    cout << "|    PRESS 'L'     |";
    SETXY(0, 11);
    cout << "|                  |";
    SETXY(0, 12);
    cout << "|                  |";
    SETXY(0, 13);
    cout << "|                  |";
    SETXY(0, 14);
    cout << "|                  |";
    SETXY(0, 15);
    cout << "|                  |";
    SETXY(0, 16);
    cout << "|                  |";
    SETXY(0, 17);
    cout << "|                  |";
    SETXY(0, 18);
    cout << "____________________";

    switch (_getch())
    {
    case 32:
        return 1;
        break;
    case 108:
        return 2;
        break;
    }
    return 1;
}

int GamePlay::LoadstartUp()
{
    // all values once the game starts
    // Read player data from the text file
    ifstream inFile("player.txt");
    if (inFile.is_open())
    {
        inFile >> GameLevel;
        inFile >> Heli.score;
        inFile >> Heli.life;
        inFile >> Heli.Location;
        inFile >> Heli.myHeliX;
        inFile >> Heli.myHeliY;
        inFile >> Laser.myLaserX;
        inFile >> Laser.myLaserY;
        inFile.close();
    }
    else
    {
        cerr << "Unable to open file for reading." << endl;
    }

    srand(time(NULL));
    exitGame = false;
    Heli.Move = false;
    gameOver = false;
    Heli.dead = false;
    Heli.Collision = false;
    height = 20;
    width = 20;
    Enemy.NumberOfEnemys = 2;
    for (int i = 0; i < Enemy.NumberOfEnemys; i++)
    {
        Enemy.EPX = rand() % 3;
        if (Enemy.EPX == 0)
            Enemy.enemyX[i] = 2;
        else if (Enemy.EPX == 1)
            Enemy.enemyX[i] = 8;
        else if (Enemy.EPX == 2)
            Enemy.enemyX[i] = 14;
    }
    Enemy.enemyY[0] = -8;
    Enemy.enemyY[1] = -18;
    Enemy.enemyY[2] = -28;
    Enemy.enemyY[3] = -38;
    if (GameLevel == "EASY")
    {
        return 1;
    }
    else if (GameLevel == "MEIUM")
    {
        return 2;
    }
    else
    {
        return 3;
    }
}
