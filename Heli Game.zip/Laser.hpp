#ifndef LASER_HPP
#define LASER_HPP
#include <iostream>
#include <string>
#include "./MyHeli.hpp"

class MyLaser : private MyHeli
{

friend class GamePlay;

private:

    int myLaserX;
    int myLaserY;

    bool dead;

    std::string Laser1[11] = {
        "  ^  ",
        "     ",
        "  ^  ",
        "     ",
        "  ^  ",
        "     ",
        "  ^  ",
        "     ",
        "  ^  ",
        "     ",
        "  ^  ",
    };
    std::string Laser2[12] = {
        "  ^  ",
        "     ",
        "  ^  ",
        "     ",
        "  ^  ",
        "     ",
        "  ^  ",
        "     ",
        "  ^  ",
        "     ",
        "  ^  ",
        "     ",
    };

public:
    void SETXY(int x, int y);
    void drawMyLasere();
};
#endif /* LASER_HPP */
