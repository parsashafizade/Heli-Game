#include "Laser.hpp"
#include <windows.h>
#include <stdlib.h>
#include <time.h>
#include <conio.h>
#include <fstream>
#include <chrono>
#include <thread>

using namespace std;

void MyLaser::SETXY(int x, int y)
{
    // to print in any place you want
    COORD coord;
    coord.X = x;
    coord.Y = y;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}

void MyLaser::drawMyLasere()
{
    // to print your Heli Lasere
    if (!dead)
    {
        Sleep(2);
        for (int i = 0; i < 11; i++)
        {
            SETXY(myLaserX, myLaserY + i);
            cout << Laser1[i];
        }
        Sleep(2);
        for (int i = 0; i < 11; i++)
        {
            SETXY(myLaserX, myLaserY + i + 1);
            cout << Laser1[i];
        }
    }
    else
    {
        for (int i = 0; i < 11; i++)
        {
            SETXY(myLaserX, myLaserY + i);
            cout << "    ";
        }
    }
}
