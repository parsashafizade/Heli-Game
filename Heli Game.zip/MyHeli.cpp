#include "MyHeli.hpp"
#include <windows.h>
#include <stdlib.h>
#include <time.h>
#include <conio.h>
#include <fstream>
#include <chrono>
#include <thread>

using namespace std;

void MyHeli::SETXY(int x, int y)
{
    // to print in any place you want
    COORD coord;
    coord.X = x;
    coord.Y = y;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}

void MyHeli::drawMyHeli()
{
    // to print your Heli
    if (!dead)
    {
        for (int i = 0; i < 4; i++)
        {
            SETXY(myHeliX, myHeliY + i);
            cout << myHeli[i];
        }
    }
    else
    {
        for (int i = 0; i < 4; i++)
        {
            SETXY(myHeliX, myHeliY + i);
            cout << "    ";
        }
    }
}

void MyHeli::CollisionHeli()
{
    if (Collision)
    {
        for (int i = 0; i < 4; i++)
        {
            SETXY(myHeliX - 1, myHeliY - 1 + i);
            cout << Collision1[i] << endl;
        }
        Collision = false;
    }
    else
    {
        for (int i = 0; i < 4; i++)
        {
            SETXY(myHeliX - 1, myHeliY - 1 + i);
            cout << Collision2[i] << endl;
        }
        Collision = true;
    }
    Sleep(100);
}
