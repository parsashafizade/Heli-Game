#include "Gameplay.hpp"

int main()
{
    GamePlay HeliGame;
    HeliGame.play();
}

