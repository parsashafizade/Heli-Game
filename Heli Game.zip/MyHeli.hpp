#ifndef MYHELI_HPP
#define MYHELI_HPP
#include <iostream>
#include <string>
class MyHeli
{
friend class GamePlay;
private:
    int life;
    int Location;
    int score;
    int myHeliX;
    int myHeliY;

    bool dead;
    bool Move;
    bool Collision;

    std::string Collision1[4] = {"o   o", " ooo ", " ooo ", "o   o"};
    std::string Collision2[4] = {" ooo ", "o   o", "o   o", " ooo "};

    std::string myHeli[4] = {
        "  ^  ",
        " /|\\ ",
        " \\|/ ",
        " *** ",
    };

public:
    void SETXY(int x, int y);
    void drawMyHeli();
    void CollisionHeli();
};

#endif /* MYHELI_HPP */