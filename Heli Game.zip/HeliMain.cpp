#include "./HeliHeader.hpp"

int main()
{
    heli Game;
    Game.play();
}
