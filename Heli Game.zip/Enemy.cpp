#include "Enemy.hpp"
#include <windows.h>
#include <stdlib.h>
#include <time.h>
#include <conio.h>
#include <fstream>
#include <chrono>
#include <thread>

using namespace std;

void EnemyHeli::SETXY(int x, int y)
{ // to print in any place you want
    COORD coord;
    coord.X = x;
    coord.Y = y;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}

void EnemyHeli::drawEnemyHeli()
{
    // to print enemy Heli
    for (int i = 0; i < NumberOfEnemys; i++)
    {
        if (enemyY[i] + 3 > 0)
        {
            SETXY(enemyX[i], enemyY[i] + 3);
            cout << " # ";
        }
        if (enemyY[i] + 2 > 0)
        {
            SETXY(enemyX[i], enemyY[i] + 2);
            cout << "# #";
        }
        if (enemyY[i] + 3 > 20)
        {
            SETXY(enemyX[i], enemyY[i] + 3);
            cout << "   ";
        }
        if (enemyY[i] + 2 > 20)
        {
            SETXY(enemyX[i], enemyY[i] + 2);
            cout << "   ";
        }
        if (enemyY[i] + 1 > 20)
        {
            SETXY(enemyX[i], enemyY[i] + 1);
            cout << "   ";
        }
        if (enemyY[i] > 20)
        {
            SETXY(enemyX[i], enemyY[i]);
            cout << "   ";
        }
    }
}

void EnemyHeli::createenemy()
{
    for (int i = 0; i < NumberOfEnemys; i++)
    { // setting new enemy positions
        if (enemyY[i] > 21)
        {
            EPX = rand() % 3;
            if (EPX == 0)
                enemyX[i] = 2;
            else if (EPX == 1)
                enemyX[i] = 8;
            else if (EPX == 2)
                enemyX[i] = 14;
            enemyY[i] = -8;
            // score += 1;
        }
    }
}
