#ifndef ENEMY_HPP
#define ENEMY_HPP
#include <iostream>
#include <string>
class EnemyHeli
{

friend class GamePlay;

private:
    int EPX;
    int EPY;
    int NumberOfEnemys;
    int enemyHP;

    int enemyX[4];
    int enemyY[4] = {-8, -18, -28, -38};

public:
    void SETXY(int x, int y);
    void drawEnemyHeli();
    void createenemy();
};
#endif /* ENEMY_HPP */
