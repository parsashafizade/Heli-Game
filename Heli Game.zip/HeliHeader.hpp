#ifndef C3684005_CF6C_41F8_8E71_6B0F5EC590EF
#define C3684005_CF6C_41F8_8E71_6B0F5EC590EF
#include <iostream>
#include <string>
class heli
{
private:

    int life;
    int width;
    int height;
    int Location;
    int score;
    int myHeliX;
    int myHeliY;
    int myLaserX;
    int myLaserY;
    int EPX;
    int EPY;
    int NumberOfEnemys;
    int enemyHP;

    std::string GameLevel;

    bool dead;
    bool exitGame;
    bool gameOver;
    bool Move;
    bool Collision;
    
    int enemyX[4];
    int enemyY[4] = {-8, -18, -28, -38};


    std::string Collision1[4] = {"o   o", " ooo ", " ooo ", "o   o"};
    std::string Collision2[4] = {" ooo ", "o   o", "o   o", " ooo "};

    std::string myHeli[4] = {
        "  ^  ",
        " /|\\ ",
        " \\|/ ",
        " *** ",
    };
    std::string Laser1[11] = {
        "  ^  ",
        "     ",
        "  ^  ",
        "     ",
        "  ^  ",
        "     ",
        "  ^  ",
        "     ",
        "  ^  ",
        "     ",
        "  ^  ",
    };
    std::string Laser2[12] = {
        "  ^  ",
        "     ",
        "  ^  ",
        "     ",
        "  ^  ",
        "     ",
        "  ^  ",
        "     ",
        "  ^  ",
        "     ",
        "  ^  ",
        "     ",
    };

public:
    void SETXY(int x, int y);
    
    void Preparation(std::string gamelevel);
    void reposition();
    void layout();
    void drawMyHeli();
    void drawMyLasere();
    void drawEnemyHeli();
    void input();
    void CollisionHeli();
    void Death();
    void createenemy();
    void Logic1();
    void Logic2();
    void hideCursor();
    void Moving();
    void inScore();
    void game_Over();
    void game_Saved();
    void play();
    void playLoadGame();
    void chosseLEVEL();
    void EasyGame();
    void MediumGame();
    void HardGame();

    int  games();
    int  LoadstartUp();
};
#endif /* C3684005_CF6C_41F8_8E71_6B0F5EC590EF */
